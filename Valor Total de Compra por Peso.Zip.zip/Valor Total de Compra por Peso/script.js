function CalcularValor() {
    const valorPago = parseFloat(document.getElementById("valor1").value);
    const precoProduto = parseFloat(document.getElementById("quantidade1").value);
    const Total = valorPago * precoProduto;
    document.getElementById("Resultado").innerText = " Valor do peso: R$ " + Total.toFixed(2);
}