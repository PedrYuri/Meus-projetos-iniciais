function calcularTroco() {
    const pago = parseFloat(document.getElementById("valorPago").value);
    const preco = parseFloat(document.getElementById("precoProduto").value);
    const troco = pago - preco;
    document.getElementById("resultado1").innerText = "Troco: R$ " + troco.toFixed(2); 
}
function calcularValorFinal() {
    const valorKg = parseFloat(document.getElementById("valorQuilo").value);
    const quantidade = parseFloat(document.getElementById("quantidadeQuilo").value);
    const total = valorKg * quantidade;
    document.getElementById("resultado2").innerText = "Valor a pagar: R$ " + total.toFixed(2);
}

function reajustarSaldo() {
    const saldo = parseFloat(document.getElementById("saldo").value);
    const novoSaldo = saldo * 1.01;
    document.getElementById("resultado3").innerText = "Saldo com reajuste: R$ " + novoSaldo.toFixed(2);
}