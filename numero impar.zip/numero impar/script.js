function verificar() {
    let num = parseInt(document.getElementById("num").value);
    let resposta = num % 2 !== 0 ? "Impar" : "Nao e Impar";
    document.getElementById("resultado").textContent = resposta;
}