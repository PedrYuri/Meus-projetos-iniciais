function calcularOmelete() {
  const pessoas = parseInt(document.getElementById("pessoas").value);

  if (isNaN(pessoas) || pessoas <= 0) {
    document.getElementById("resultado2").innerHTML = "Por favor, insira um número válido de pessoas.";
    return;
  }

  const ovosPorPessoa = 2;
  const queijoPorPessoa = 50; 

  const totalOvos = pessoas * ovosPorPessoa;
  const totalQueijo = pessoas * queijoPorPessoa;

  document.getElementById("resultado2").innerHTML =
    `Para ${pessoas} pessoa(s), voce vai precisar de:<br>
     ${totalOvos} ovos<br>
     ${totalQueijo}g de queijo`;
}