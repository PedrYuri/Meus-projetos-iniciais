function menor() {
    let n1 = parseFloat(document.getElementById("n1").value);
    let n2 = parseFloat(document.getElementById("n2").value);
    let n3 = parseFloat(document.getElementById("n3").value);
    let n4 = parseFloat(document.getElementById("n4").value);
    let menor = Math.min(n1, n2, n3, n4);
    document.getElementById("saida").textContent = "Menor valor: " + menor;
}