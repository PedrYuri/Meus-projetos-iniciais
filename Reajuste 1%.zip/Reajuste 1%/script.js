function reajuste() {

    let valor = parseFloat(document.getElementById("reajuste").value);
    let resultado = valor * 1.01;
    document.getElementById("resultado").textContent = "Resultado: " + resultado.toFixed(2);

}