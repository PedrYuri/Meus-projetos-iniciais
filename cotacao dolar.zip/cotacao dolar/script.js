function calcular() {
  const valor = parseFloat(document.getElementById('dolar').value);
  if (isNaN(valor)) {
    document.getElementById('resultado1').innerHTML = "Por favor, insira um valor válido.";
    return;
  }

  const taxas = [1, 2, 5, 10];
  let resultado = "";

  taxas.forEach(taxa => {
    const novoValor = valor + (valor * taxa / 100);
    resultado += `Com aumento de ${taxa}%: U$ ${novoValor.toFixed(2)}<br>`;
  });

  document.getElementById('resultado1').innerHTML = resultado;
}