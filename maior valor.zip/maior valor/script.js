function maior() {
    let v1 = parseFloat(document.getElementById("v1").value);
    let v2 = parseFloat(document.getElementById("v2").value);
    let maior = v1 > v2 ? v1 : v2;
    document.getElementById("resposta").textContent = "Maior valor: " + maior;
}