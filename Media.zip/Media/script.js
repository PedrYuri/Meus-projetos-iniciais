function calcular() {
    let n1 = parseFloat(document.getElementById("n1").value);
    let n2 = parseFloat(document.getElementById("n2").value);
    let n3 = parseFloat(document.getElementById("n3").value);

    let mediaAritmetica = (n1 + n2 + n3) / 3;
    let mediaPonderada = (n1 * 3 + n2 * 2 + n3 * 5) / 10;
    let somaMedias = mediaAritmetica + mediaPonderada;
    let mediaDasMedias = somaMedias / 2;

    let resultado = "";
    resultado += "Media Aritmetica: " + mediaAritmetica.toFixed(2) + "<br>";
    resultado += "Media Ponderada: " + mediaPonderada.toFixed(2) + "<br>";
    resultado += "Soma das Medias: " + somaMedias.toFixed(2) + "<br>";
    resultado += "Media das Medias: " + mediaDasMedias.toFixed(2);

    document.getElementById("resultado").innerHTML = resultado;
}